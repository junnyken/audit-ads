// AdsOps Companion Extension v2.1 — Background Service Worker (Manifest V3)
let currentAuth = { user: "", pass: "" };

function parseProxy(raw) {
  if (!raw) return null;
  const s = String(raw).trim();
  const mAt = s.match(/^(?:(http|https|socks5):\/\/)?([^:\s]+):([^@\s]+)@(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})$/i);
  if (mAt) {
    return { scheme: (mAt[1] || "http").toLowerCase(), user: mAt[2], pass: mAt[3], host: mAt[4], port: parseInt(mAt[5], 10) };
  }
  const m4 = s.match(/(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5}):([^:\s]+):([^\s]+)/);
  if (m4) {
    return { scheme: "http", host: m4[1], port: parseInt(m4[2], 10), user: m4[3], pass: m4[4] };
  }
  const m2 = s.match(/(\d{1,3}(?:\.\d{1,3}){3}):(\d{2,5})/);
  if (m2) {
    return { scheme: "http", host: m2[1], port: parseInt(m2[2], 10), user: "", pass: "" };
  }
  return null;
}

function applyProxyState(state) {
  const enabled = Boolean(state && state.proxyEnabled);
  const parsed = enabled ? parseProxy(state.proxyRaw) : null;
  if (parsed) {
    currentAuth = { user: parsed.user || "", pass: parsed.pass || "" };
    const config = {
      mode: "fixed_servers",
      rules: {
        singleProxy: {
          scheme: parsed.scheme,
          host: parsed.host,
          port: parsed.port
        },
        bypassList: ["localhost", "127.0.0.1"]
      }
    };
    chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {});
    chrome.action.setBadgeText({ text: "PRX" });
    chrome.action.setBadgeBackgroundColor({ color: "#15803d" });
  } else {
    currentAuth = { user: "", pass: "" };
    chrome.proxy.settings.clear({ scope: "regular" }, () => {});
    const badge = (state && state.profileCode) ? String(state.profileCode).slice(0, 4).toUpperCase() : "VIA";
    chrome.action.setBadgeText({ text: badge });
    chrome.action.setBadgeBackgroundColor({ color: "#1d4ed8" });
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["viaName", "profileCode", "proxyRaw", "proxyEnabled"], (res) => {
    const init = {
      viaName: res.viaName || "Tài Khoản Chính (Via Tổng)",
      profileCode: res.profileCode || "Default",
      proxyRaw: res.proxyRaw || "",
      proxyEnabled: Boolean(res.proxyEnabled)
    };
    chrome.storage.local.set(init, () => applyProxyState(init));
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local") {
    chrome.storage.local.get(["viaName", "profileCode", "proxyRaw", "proxyEnabled"], (res) => {
      applyProxyState(res);
    });
  }
});

chrome.webRequest.onAuthRequired.addListener(
  (details) => {
    if (currentAuth.user && currentAuth.pass) {
      return {
        authCredentials: {
          username: currentAuth.user,
          password: currentAuth.pass
        }
      };
    }
    return {};
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
// AdsOps Companion Extension v2.1 — Popup Controller
const viaInput = document.getElementById("via-name");
const profileInput = document.getElementById("profile-code");
const proxyInput = document.getElementById("proxy-raw");
const badge = document.getElementById("proxy-badge");
const saveMsg = document.getElementById("save-msg");
const liveIp = document.getElementById("live-ip");

function refreshIp() {
  if (!liveIp) return;
  liveIp.textContent = "Đang kiểm tra...";
  fetch("https://api.ipify.org?format=json")
    .then((r) => r.json())
    .then((d) => {
      if (d && d.ip) liveIp.textContent = d.ip;
    })
    .catch(() => {
      liveIp.textContent = "Không kết nối được";
    });
}

function updateBadge(enabled, raw) {
  if (!badge) return;
  if (enabled && raw && raw.trim()) {
    badge.textContent = "ĐANG BỌC PROXY";
    badge.className = "status-pill active";
  } else {
    badge.textContent = "MẠNG TRỰC TIẾP";
    badge.className = "status-pill";
  }
}

function flashSaved() {
  if (!saveMsg) return;
  saveMsg.style.display = "inline";
  setTimeout(() => {
    saveMsg.style.display = "none";
  }, 1800);
}

if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
  chrome.storage.local.get(["viaName", "profileCode", "proxyRaw", "proxyEnabled"], (res) => {
    if (viaInput) viaInput.value = res.viaName || "Tài Khoản Chính (Via Tổng)";
    if (profileInput) profileInput.value = res.profileCode || "Default";
    if (proxyInput) proxyInput.value = res.proxyRaw || "";
    updateBadge(Boolean(res.proxyEnabled), res.proxyRaw || "");
  });
}

document.getElementById("btn-save-enable")?.addEventListener("click", () => {
  const raw = (proxyInput?.value || "").trim();
  const state = {
    viaName: (viaInput?.value || "").trim() || "Via Facebook",
    profileCode: (profileInput?.value || "").trim() || "Default",
    proxyRaw: raw,
    proxyEnabled: Boolean(raw)
  };
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set(state, () => {
      updateBadge(state.proxyEnabled, state.proxyRaw);
      flashSaved();
      setTimeout(refreshIp, 600);
    });
  }
});

document.getElementById("btn-disable-proxy")?.addEventListener("click", () => {
  const state = {
    viaName: (viaInput?.value || "").trim() || "Via Facebook",
    profileCode: (profileInput?.value || "").trim() || "Default",
    proxyRaw: (proxyInput?.value || "").trim(),
    proxyEnabled: false
  };
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set(state, () => {
      updateBadge(false, "");
      flashSaved();
      setTimeout(refreshIp, 600);
    });
  }
});

// Detect active Facebook / Meta tab for act_id or business_id
if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.query) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs?.[0]?.url || "";
    const actMatch = url.match(/(?:act=|act_)(\d{6,25})/i);
    const bmMatch = url.match(/business_id=(\d{6,25})/i);
    if (actMatch || bmMatch) {
      const box = document.getElementById("fb-detected");
      const txt = document.getElementById("fb-detected-text");
      const copyBtn = document.getElementById("btn-copy-id");
      const parts = [];
      const primaryId = actMatch ? actMatch[1] : bmMatch[1];
      if (bmMatch) parts.push("BM ID: " + bmMatch[1]);
      if (actMatch) parts.push("TKQC ID: " + actMatch[1]);
      if (box && txt) {
        txt.textContent = parts.join(" · ");
        box.style.display = "block";
      }
      copyBtn?.addEventListener("click", () => {
        navigator.clipboard.writeText(primaryId);
        copyBtn.textContent = "Đã chép: " + primaryId;
      });
    }
  });
}

refreshIp();
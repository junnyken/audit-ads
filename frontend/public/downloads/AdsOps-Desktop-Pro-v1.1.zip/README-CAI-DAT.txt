ADSOPS DESKTOP PRO v1.1 - UNG DUNG WINDOWS DIEU PHOI DAN VIA & EXTENSION v2.9.1
====================================================================================
Tinh nang moi v1.1:
1. Tu dong nap danh sach TKQC & Du no that (DEFAULT_ACCOUNTS) vao popup Extension cua tung Via.
2. Ket Sat Cookie & 2FA Local (ma hoa Windows DPAPI ngay tren may, KHONG gui Cookie len Cloud):
   Bam nut «Luu vao Ket App Win» trong Chrome Extension hoac bam cot «Ket Sat Ck/2FA» tren App Windows.
3. Tu dong dong bo vao file sao luu .adsopsvault (PBKDF2 + AES-256-GCM).
4. Tu dong thay the Cau noi .bat cu tren cong 17890 & ho tro menu Mo nhanh / Dao Am ngay tu System Tray.

Cach dung:
1. Chay AdsOpsDesktop.exe -> Bam 'Gan Protocol 1-Cham' (khong can quyen Admin).
2. Dang nhap tai khoan AdsOps Cloud de dong bo Dan Via, TKQC & bat Cau noi 2 chieu voi Web/Telegram.
3. (Khuyen nghi) Bat 'Khoi dong cung Windows' va 'Co lap 100% Chrome Profile' neu muon auto-load Extension.

Luu y: Yeu cau Windows 10/11 va .NET 8 Desktop Runtime (x64).